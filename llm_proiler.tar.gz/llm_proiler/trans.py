import json
import pandas as pd 


# 读取xlsx文件
input_file = '/workspace/llm_proiler/custom_data/103775_data_021441_chat_completions_20240808_0.xlsx'
df = pd.read_excel(input_file)

# 将DataFrame转换为字典
data_dict = df.to_dict(orient='records')

# 将字典转换为JSON字符串
json_data = json.dumps(data_dict, indent=4, ensure_ascii=False)

# 将JSON字符串写入文件
output_file = 'output.json'
with open(output_file, 'w', encoding='utf-8') as json_file:
    json_file.write(json_data)

print(f"数据已成功从 {input_file} 转换为 {output_file}")


with open(output_file, 'r') as json_file:
    data = json.load(json_file)

prompts = []

for item in data:
    prompts.append(item['request'])

out = {}

out["querys"] = prompts

with open('data2.json', "w", encoding='utf-8') as json_file:
    json.dump(prompts, json_file, indent=4, ensure_ascii=False)