from setuptools import setup, find_packages

setup(
    name="llm_profiler",
    version="1.0.0",
    packages=find_packages(
        exclude=("build", "include", "test", "dist", "docs", "benchmarks", "llm_profiler.egg-info")
    ),
    entry_points={
        "console_scripts": [
            "llm_profiler = llm_profiler.main:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Linux",
    ],
    python_requires='>=3.9',
    install_requires=[
        "easydict",
        "matplotlib",
        "datasets==2.18.0",
    ],
)
