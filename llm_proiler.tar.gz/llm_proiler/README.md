# llm_profiler

这是一个测试大模型速度的工具

### 支持以下功能：
- stream或者非stream模式
- 自定义数据集或者在开源pileval数据集中随机选取
- 测试并发数控制
- 以分位点展示测试结果
- 可以对输入数据的长度，设置不同的分布概率，进行测试


### 使用方式：
```
python main.py --config [配置文件路径]
```

**对于nostream模式，工具会返回整包的分位点延迟**

**对于stream模型，工具会返回首包和包间的分位点延迟**


### 配置文件说明：

本仓库已经提供了几个配置例子，下面以其中两个配置说明

自定义数据集的测速

```
seed: 0 # 随机数种子
url: http://101.230.144.204:9857/generate_stream # 服务地址
post_mode: stream # 可选择stream和nostream
max_workers: 5 # 测试的并发数控制
data_source: custom # 数据集来源，可以选择custom或者pileval
data_path: custom_data/data.json # 数据集路径，格式以仓库中的custom_data/data.json文件为准，每一行是一条数据，以字典形式表示。
input_num: all # 测试数据的数量，可以设置成all或者某个数字
output_len: 10 # 输出最大长度
percentiles: [25, 50, 75, 90, 95, 99, 100] # 分位点
```

pileval数据集中随机输入的测速，采用高斯分布输入长度

```
seed: 0 # 随机数种子
url: http://localhost:8080/generate_stream # 服务地址
post_mode: stream # 可选择stream和nostream
max_workers: 5 # 测试的并发数控制
data_source: pileval # 若选pileval，即在pileval数据集中随机选取一些输入，那需要先下载好pileval数据集，下载脚本是download_pileval.py
data_path: /mnt/nvme1/yongyang/llm_datasets/llmc/calib/pileval # pileval数据集的下载路径
tokenizer_path: /mnt/nvme1/yongyang/llm_weights/qwen2/Qwen2-0.5B # 如果是pileval数据集，因为要获取seqlen，所以需要指定模型的tokenizer路径
data_mode: gaussian # 当data_source为pileval，data_mode有效，表示seqlen的分布概率，可选uniform，random，gaussian，increasing，decreasing
input_len: [256, 1024] # seqlen的最小值和最大值。如果data_mode是uniform，input_len给一个数字，如果data_mode是别的分布，需要给一个列表，比如[256, 1024]
input_num: 100 # 测试数据的数量，当data_source为pileval，input_num只能给一个数字，不能给all
output_len: 10 # 输出最大长度
show_seqlen: True # 是否存下来seqlen的分布直方图，仅仅在data_source为pileval有效
percentiles: [25, 50, 75, 90, 95, 99, 100] # 分位点
```

注意：使用download_pileval.py下载数据集的时候，需要在终端开vpn。在测速度的时候，要关闭vpn。

注意：如果要使用对话模板，可以在data.py中的chat_format函数进行修改，并在get_custom_input_data函数中调用。当然你也可以直接在custom_data/data.json中，拼好模板。
