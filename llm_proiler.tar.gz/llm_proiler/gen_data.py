from llm_profiler.data import *
import json

data_path = "/workspace/llm_proiler/custom_data/data2.json"

prompts, input_lens = get_own_data(data_path)

with open("xiaomi-data.json", "w", encoding='utf-8') as fp:
    for prompt in prompts:
        json_data = {}
        json_data["query"] = prompt
        fp.write(json.dumps(json_data, ensure_ascii=False) + "\n")
