import os
import random
import numpy as np
import matplotlib.pyplot as plt


def update_config_from_args(config, args):
    if args.url:
        config.url = args.url
        if "http" not in args.url:
            config.url = f"http://{args.url}"
    if args.num_clients:
        config.max_workers = args.num_clients
    if args.post_mode:
        config.post_mode = args.post_mode
    if args.data_source:
        config.data_source = args.data_source
    if args.data_path:
        config.data_path = args.data_path
    if args.tokenizer_path:
        config.tokenizer_path = args.tokenizer_path
    if args.data_mode:
        config.data_mode = args.data_mode
    if args.input_len:
        config.input_len = args.input_len
    if args.input_num:
        config.input_num = args.input_num
    if args.output_len:
        config.output_len = args.output_len
    return config

def uniform_distribution(input_ids, input_num, input_len):
    print("uniform_distribution")
    assert isinstance(input_len, int)
    prompts_ids = []
    for _ in range(input_num):
        i = random.randint(0, len(input_ids) - input_len - 1)
        j = i + input_len
        inp = input_ids[i:j]
        prompts_ids.append(inp)
    return prompts_ids

def random_distribution(input_ids, input_num, input_len):
    print("random_distribution")
    assert isinstance(input_len, list)
    min_len, max_len = input_len
    prompts_ids = []
    for _ in range(input_num):
        cur_len = random.randint(min_len, max_len)
        i = random.randint(0, len(input_ids) - cur_len - 1)
        j = i + cur_len
        inp = input_ids[i:j]
        prompts_ids.append(inp)
    return prompts_ids

def gaussian_distribution(input_ids, input_num, input_len):
    print("gaussian_distribution")
    if isinstance(input_len, list):
        min_len, max_len = input_len
    else:
        min_len, max_len = 1, input_len * 2
    mean = (min_len + max_len) * 0.5
    std = (max_len - mean) / 3.0 # 3std准则
    prompts_ids = []
    for _ in range(input_num):
        cur_len = random.gauss(mean, std)
        cur_len = round(cur_len)
        if cur_len < min_len:
            cur_len = min_len
        elif cur_len > max_len:
            cur_len = max_len
        i = random.randint(0, len(input_ids) - cur_len - 1)
        j = i + cur_len
        inp = input_ids[i:j]
        prompts_ids.append(inp)
    return prompts_ids

def increasing_distribution(input_ids, input_num, input_len):
    print("increasing_distribution")
    assert isinstance(input_len, list)
    min_len, max_len = input_len
    weights = range(1, max_len - min_len + 2)
    len_choices = range(min_len, max_len + 1)
    list_len = random.choices(len_choices, weights=weights, k=input_num)
    prompts_ids = []
    for cur_len in list_len:
        i = random.randint(0, len(input_ids) - cur_len - 1)
        j = i + cur_len
        inp = input_ids[i:j]
        prompts_ids.append(inp)
    return prompts_ids

def decreasing_distribution(input_ids, input_num, input_len):
    print("decreasing_distribution")
    assert isinstance(input_len, list)
    min_len, max_len = input_len
    weights = range(max_len - min_len + 1, 0, -1)
    len_choices = range(min_len, max_len + 1)
    list_len = random.choices(len_choices, weights=weights, k=input_num)
    prompts_ids = []
    for cur_len in list_len:
        i = random.randint(0, len(input_ids) - cur_len - 1)
        j = i + cur_len
        inp = input_ids[i:j]
        prompts_ids.append(inp)
    return prompts_ids

def show_seqlen_distribution(prompts_ids):
    seqlen_data = [len(prompts_id) for prompts_id in prompts_ids]
    plt.hist(seqlen_data, bins=10, edgecolor='black')
    plt.savefig('seqlen_data.png')

def seed_all(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
