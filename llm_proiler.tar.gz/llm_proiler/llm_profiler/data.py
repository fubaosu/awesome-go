from datasets import load_from_disk
from transformers import AutoTokenizer
import json
from llm_profiler.utils import *
import random 
import fastchat
from fastchat.conversation import Conversation, SeparatorStyle
from fastchat.model.model_adapter import get_conversation_template

def get_pileval_input_data(data_path, tokenizer_path, input_len, input_num, mode="uniform", show_seqlen=False):
    print("Loading pileval data...")
    data = load_from_disk(data_path)
    data = '\n'.join(data['text'][:3000])
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, trust_remote_code=True)
    input_ids = tokenizer.encode(data)
    if mode == "uniform":
        prompts_ids = uniform_distribution(input_ids, input_num, input_len)
    elif mode == "random":
        prompts_ids = random_distribution(input_ids, input_num, input_len)
    elif mode == "gaussian":
        prompts_ids = gaussian_distribution(input_ids, input_num, input_len)
    elif mode == "increasing":
        prompts_ids = increasing_distribution(input_ids, input_num, input_len)
    elif mode == "decreasing":
        prompts_ids = decreasing_distribution(input_ids, input_num, input_len)
    else:
        raise Exception(f'Not support {mode} mode.')

    if show_seqlen:
        show_seqlen_distribution(prompts_ids)

    prompts = []
    input_lens = []
    for prompts_id in prompts_ids:
        text = tokenizer.decode(prompts_id)
        prompts.append(text)
        input_lens.append(len(prompts_id))
    print("Finish loading.")
    return prompts, input_lens

def chat_format(query):
    template = "<|im_start|>system\n你是一个乐于助人的人工智能助手。<|im_end|>\n<|im_start|>user\n<to_be_replaced><|im_end|>\n<|im_start|>assistant\n"
    input_text = template.replace("<to_be_replaced>", query)
    return input_text

def get_custom_input_data(data_path, input_num="all"):
    with open(data_path) as file:
        lines = file.readlines()
    input_datas = [json.loads(line) for line in lines]
    prompts = []
    for i in range(len(input_datas)):
        input_text = input_datas[i]['query']
        # input_text = chat_format(input_datas[i]['query']) # 对话模板设置
        prompts.append((input_text, None))
        if isinstance(input_num, int) and len(prompts) == input_num:
            break
    return prompts

def build_prompt(chat_list):
    conv = get_conversation_template("llama2")
    conv = Conversation(
        name=conv.name,
        system_template=conv.system_template,
        system_message=conv.system_message,
        roles=conv.roles,
        messages=list(),  # prevent in-place modification
        offset=conv.offset,
        sep_style=SeparatorStyle(conv.sep_style),
        sep=conv.sep,
        sep2=conv.sep2,
        stop_str=conv.stop_str,
        stop_token_ids=conv.stop_token_ids,
    )
    
    if isinstance(chat_list, str):
        prompt = chat_list
    else:
        for message in chat_list:
            msg_role = message["role"]
            if msg_role == "system":
                conv.system_message = message["content"]
            elif msg_role == "user":
                conv.append_message(conv.roles[0], message["content"])
            elif msg_role == "assistant":
                conv.append_message(conv.roles[1], message["content"])
            else:
                raise ValueError(f"Unknown role: {msg_role}")
        # Add a blank message for the assistant. Meaning it's the assistant's turn to talk.
        conv.append_message(conv.roles[1], None)
        prompt = conv.get_prompt()
    return prompt

def get_own_data(data_path, input_num="all", tokenizer_path="/nvme/models/llama2-13b-chat"):
    with open(data_path, "r", encoding='utf-8') as file:
        prompts = json.load(file)
        prompts = prompts["querys"]

        random.shuffle(prompts)

    if isinstance(input_num, int) and len(prompts) > input_num:
        prompts = prompts[:input_num]

    prompts = [json.loads(prompt) for prompt in prompts]
    prompts = [build_prompt(prompt) for prompt in prompts]

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, trust_remote_code=True)

    input_lens = []
    for prompt in prompts:
        ids = tokenizer.encode(prompt)
        input_lens.append(len(ids))
    return prompts, input_lens

def get_output_length(input_num, output_len):
    min_len, max_len = 1, output_len * 2
    mean = (min_len + max_len) * 0.5
    std = (max_len - mean) / 3.0 # 3std准则
    output_lens = []
    for _ in range(input_num):
        cur_len = random.gauss(mean, std)
        cur_len = round(cur_len)
        if cur_len < min_len:
            cur_len = min_len
        elif cur_len > max_len:
            cur_len = max_len
        output_lens.append(cur_len)
    return output_lens 

